/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package wow.client;

/**
 *
 * @author beh01
 */
public class WowClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ClientGUI client = new ClientGUI();
        client.setVisible(true);
    }
}
